// script.js
document.getElementById('predictButton').addEventListener('click', function() {
    // Get the form values
    const age = parseInt(document.getElementById('age').value);
    const gender = parseInt(document.getElementById('gender').value);
    const chestpain = parseInt(document.getElementById('chestpain').value);
    const restingBP = parseInt(document.getElementById('restingBP').value);
    const serumcholestrol = parseInt(document.getElementById('serumcholestrol').value);
    const fastingbloodsugar = parseInt(document.getElementById('fastingbloodsugar').value);
    const restingrelectro = parseInt(document.getElementById('restingrelectro').value);
    const maxheartrate = parseInt(document.getElementById('maxheartrate').value);
    const exerciseangia = parseInt(document.getElementById('exerciseangia').value);
    const oldpeak = parseFloat(document.getElementById('oldpeak').value);
    const slope = parseInt(document.getElementById('slope').value);
    const noofmajorvessels = parseInt(document.getElementById('noofmajorvessels').value);

    // Simple cardiovascular risk calculation formula (modify as needed)
    let riskScore = 0;

    // Age-based factor
    if (age > 45) riskScore += 1;
    if (age > 60) riskScore += 2;

    // Gender-based factor (Male = 1, Female = 0)
    if (gender === 1) riskScore += 1;

    // Chest Pain Type factor
    if (chestpain === 0) riskScore += 1;
    if (chestpain === 1) riskScore += 0.8;
    if (chestpain === 2) riskScore += 0.5;
    if (chestpain === 3) riskScore += 0.2;

    // Blood Pressure and Cholesterol factors
    if (restingBP > 130) riskScore += 1;
    if (serumcholestrol > 240) riskScore += 1;

    // Fasting Blood Sugar factor
    if (fastingbloodsugar === 1) riskScore += 1;

    // Electrocardiographic Results factor
    if (restingrelectro === 1) riskScore += 1;
    if (restingrelectro === 2) riskScore += 2;

    // Maximum Heart Rate factor (inverse relationship)
    if (maxheartrate < 130) riskScore += 1;

    // Exercise-Induced Angina factor
    if (exerciseangia === 1) riskScore += 1.5;

    // Oldpeak factor (Higher depression indicates higher risk)
    if (oldpeak > 1.5) riskScore += 1.5;

    // Slope factor (downsloping is more dangerous)
    if (slope === 2) riskScore += 1;

    // Major Vessels factor
    if (noofmajorvessels > 0) riskScore += 1;

    // Calculate risk percentage based on score
    let riskPercentage = (riskScore / 10) * 100; // Adjust the denominator as needed for your formula
    if (riskPercentage > 100) riskPercentage = 100; // Cap at 100%

    // Display the result
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `
        <h3>Risk Prediction</h3>
        <p>Your cardiovascular risk is estimated at <strong>${Math.round(riskPercentage)}%</strong>.</p>
        <p>Based on your inputs, your risk level is ${riskPercentage > 70 ? 'High' : riskPercentage > 40 ? 'Moderate' : 'Low'}.</p>
    `;
});
